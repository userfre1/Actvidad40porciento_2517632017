package com.suganth.flutter_music_in_background

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
