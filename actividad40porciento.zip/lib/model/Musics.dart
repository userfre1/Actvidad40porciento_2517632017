//Luis Antonio Fredy Romero Cruz
//Carnet: 25-1763-2017

class Musics {
  String title;
  String singer;
  String image;
  String url;

  Musics({this.title, this.singer, this.image, this.url});
}
